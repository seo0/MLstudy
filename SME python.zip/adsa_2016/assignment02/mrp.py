


class MRP:
    pass