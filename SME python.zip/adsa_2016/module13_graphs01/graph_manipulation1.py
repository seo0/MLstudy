# IDEA: build a graph, find a shortest path (undirected graphs)
# implement methods to remove a list of vertices and all the nodes incident on them?

# build a graph, e.g., Ulsan map

# remove a list of vertices from a graph and all the nodes incident on them